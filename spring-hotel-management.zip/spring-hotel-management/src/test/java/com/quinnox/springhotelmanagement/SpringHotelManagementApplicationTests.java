package com.quinnox.springhotelmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringHotelManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
