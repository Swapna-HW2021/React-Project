package com.hexaware.springhotelmanagement.service;

import java.util.List;

import com.hexaware.springhotelmanagement.dto.PaymentDto;
import com.hexaware.springhotelmanagement.entities.Payment;

public interface PaymentService {
	public boolean addPayment(PaymentDto dto);
	public List<Payment> getPaymentDetails();

}
