package com.hexaware.springhotelmanagement.service;

import java.util.List;

import com.hexaware.springhotelmanagement.dto.StaffDto;
import com.hexaware.springhotelmanagement.entities.Staff;

public interface StaffService {
	public boolean addStaff(StaffDto staff);
	public List<Staff> getAllStaffs();
	public boolean updateStaff(int staffId,StaffDto staff);
	public boolean deleteStaff(int staffId);
	public Staff getOneStaff(int staffId);
	
}


