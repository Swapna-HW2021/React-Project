package com.hexaware.springhotelmanagement.dao;

import java.util.List;

import com.hexaware.springhotelmanagement.dto.UserDto;
import com.hexaware.springhotelmanagement.entities.User;


public interface UserDao {

	public boolean addUser(UserDto user);
	public List<User> getAllUsers();
	public boolean updateUser(UserDto user);
	public int deleteUser(int userId);
	public User getOneUser(int userId);

}
