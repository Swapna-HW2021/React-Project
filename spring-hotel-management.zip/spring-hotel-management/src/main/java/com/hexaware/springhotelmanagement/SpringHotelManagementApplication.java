package com.hexaware.springhotelmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringHotelManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringHotelManagementApplication.class, args);
	}

}
