package com.hexaware.springhotelmanagement.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hexaware.springhotelmanagement.dao.PaymentDao;
import com.hexaware.springhotelmanagement.dto.PaymentDto;
import com.hexaware.springhotelmanagement.entities.Payment;

@Service
public class PaymentServiceImpl implements PaymentService{

	@Autowired
	PaymentDao dao;

	@Override
	public boolean addPayment(PaymentDto payment) {
		return dao.addPayment(payment);
	}

	@Override
	public List<Payment> getPaymentDetails() {
		return dao.getPaymentDetails();
	}

}
